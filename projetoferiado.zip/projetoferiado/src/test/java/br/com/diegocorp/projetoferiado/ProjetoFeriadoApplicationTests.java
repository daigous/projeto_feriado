package br.com.diegocorp.projetoferiado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoFeriadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
